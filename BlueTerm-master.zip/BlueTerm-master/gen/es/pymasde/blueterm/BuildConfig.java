/** Automatically generated file. DO NOT MODIFY */
package es.pymasde.blueterm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}