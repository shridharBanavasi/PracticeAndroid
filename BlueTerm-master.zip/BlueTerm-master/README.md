BlueTerm
========

BlueTerm is the result of mix Term and BluetoothChat sample.  http://pymasde.es/blueterm/
